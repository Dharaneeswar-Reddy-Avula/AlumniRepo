import React from 'react'

const Events = () => {
  return (
    <div className="flex w-full h-screen justify-center items-center">Data not Found
      
    </div>
  )
}

export default Events
