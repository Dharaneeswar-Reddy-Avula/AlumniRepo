import React from 'react'

const Students = () => {
  return (
    <div className="flex w-full h-screen justify-center items-center">Data not found
      
    </div>
  )
}

export default Students
