import React from 'react'

const Clg = () => {
  return (
    <div className="flex flex-w-full h-screen justify-center items-center">Data not found

      
    </div>
  )
}

export default Clg
