import React from 'react'
import Thirdeve from "../assets/Thirdeve.png";
import Fourtheve from "../assets/Fourtheve.png";
import Fiftheve from "../assets/Fiftheve.png";
const PastEvents = () => {
  return (
    <div className='my-6 mx-4 flex flex-col gap-4 mt-10'>
        <div className="text-3xl font-bold pt-2 text-blue-950">Past Events</div>
         <div className="w-full bg-gray-300 flex items-center px-[20px] opacity-20 h-[50px]">Will Update Soon ..</div>
                <div className="flex flex-col gap-6 md:flex-row justify-between">
                    {/* <div className="flex w-full md:w-[30%] flex-col">
                        <div><img src={Thirdeve} /></div>
                        <div className="text-lg flex font-bold justify-center items-center">Hello nuzvid</div>
                        <div className="text-[#4573A1]">Join us for our annual Homecoming event ,featuring the football game,the 5k run, and more.</div>
                    </div> */}
                    {/* <div className="flex w-full md:w-[30%] flex-col">
                        <div><img src={Fourtheve} /></div>
                        <div className="text-lg flex font-bold justify-center items-center">Hello nuzvid</div>
                        <div className="text-[#4573A1]">Join us for our annual Homecoming event ,featuring the football game,the 5k run, and more.</div>
                    </div>
                    <div className="flex w-full md:w-[30%] flex-col">
                        <div><img src={Fiftheve} /></div>
                        <div className="flex text-lg font-bold justify-center items-center ">Hello nuzvid</div>
                        <div className="text-[#4573A1]">Join us for our annual Homecoming event ,featuring the football game,the 5k run, and more.</div>
                    </div> */}
        
                </div>
    </div>
  )
}
    
export default PastEvents